﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Web.UI;

namespace Apress.Extensibility.Adapters
{
    public class MyCheckBoxList : CheckBoxList
    {

        [Browsable(true)]
        public string OffImage
        {
            get
            {
                if (ViewState["OffImage"] == null)
                {
                    OffImage = "";
                }
                return (string)ViewState["OffImage"];
            }
            set
            {
                ViewState["OffImage"] = value;
            }
        }

        [Browsable(true)]
        public string OnImage
        {
            get
            {
                if (ViewState["OnImage"] == null)
                {
                    OnImage = "";
                }
                return (string)ViewState["OnImage"];
            }
            set
            {
                ViewState["OnImage"] = value;
            }
        }

    }
}
