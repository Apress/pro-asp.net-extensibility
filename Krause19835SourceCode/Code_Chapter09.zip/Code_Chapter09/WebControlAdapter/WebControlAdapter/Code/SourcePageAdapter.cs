﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.Adapters;
using System.IO;
using System.Text;
using System.Web.UI;

namespace Apress.Extensibility.Adapters
{
    public class SourcePageAdapter : PageAdapter
    {

        protected override void EndRender(System.Web.UI.HtmlTextWriter writer)
        {
            StreamReader sr = File.OpenText(this.Page.Server.MapPath(this.Page.Request.Url.LocalPath));
            writer.WriteFullBeginTag("pre");
            this.Page.Server.HtmlEncode(sr.ReadToEnd(), writer);
            sr.Close();
            writer.WriteEndTag("pre");            
            base.EndRender(writer);
        }
    }
}