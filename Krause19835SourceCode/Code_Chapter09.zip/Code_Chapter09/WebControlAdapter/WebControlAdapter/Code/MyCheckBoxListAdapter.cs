﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Diagnostics;

[assembly: WebResourceAttribute("Apress.Extensibility.Adapters.Resources.OnImage.png", "image/jpg")]
[assembly: WebResourceAttribute("Apress.Extensibility.Adapters.Resources.OffImage.png", "image/jpg")]

namespace Apress.Extensibility.Adapters
{

    public class MyCheckBoxListAdapter : System.Web.UI.WebControls.Adapters.WebControlAdapter
    {

        private MyCheckBoxList CheckBoxListControl
        {
            get
            {
                return ((MyCheckBoxList)Control);
            }
        }

        protected override void RenderBeginTag(System.Web.UI.HtmlTextWriter writer)
        {
            writer.WriteLine();
            writer.WriteBeginTag("table");
            writer.Write(HtmlTextWriter.TagRightChar);
            writer.Indent++;
        }

        protected override void RenderEndTag(System.Web.UI.HtmlTextWriter writer)
        {
            writer.WriteEndTag("table");
            writer.WriteLine();
            writer.Indent--;
        }

        protected override void RenderContents(System.Web.UI.HtmlTextWriter writer)
        {
            switch (CheckBoxListControl.RepeatDirection)
            {
                case RepeatDirection.Horizontal:
                    writer.WriteBeginTag("tr");
                    writer.Indent++;
                    writer.Write(HtmlTextWriter.TagRightChar);
                    for (int i = 0; i < CheckBoxListControl.Items.Count; i++)
                    {
                        writer.WriteBeginTag("td");
                        writer.Write(HtmlTextWriter.TagRightChar);
                        RenderCheckbox(writer, i); 
                        writer.WriteEndTag("td");
                    }
                    writer.WriteEndTag("tr");
                    writer.Indent--;
                    break;
                case RepeatDirection.Vertical:
                    for (int i = 0; i < CheckBoxListControl.Items.Count; i++)
                    {
                        writer.WriteBeginTag("tr");
                        writer.Write(HtmlTextWriter.TagRightChar);
                        writer.WriteBeginTag("td");
                        writer.Write(HtmlTextWriter.TagRightChar);
                        RenderCheckbox(writer, i);
                        writer.WriteEndTag("td");
                        writer.WriteEndTag("tr");
                    }
                    break;
            }
        }

        private void RenderCheckbox(HtmlTextWriter writer, int i)
        {
            Image img = new Image();
            Label l = new Label();
            if (CheckBoxListControl.Items[i].Selected)
            {
                img.ImageUrl = Page.ClientScript.GetWebResourceUrl(this.GetType(), 
                    String.Format("Apress.Extensibility.Adapters.Resources.{0}.png", 
                    CheckBoxListControl.OnImage));
                img.ToolTip = String.Format("{0} (on) ", 
                    CheckBoxListControl.Items[i].Text);
            }
            else
            {
                img.ImageUrl = Page.ClientScript.GetWebResourceUrl(this.GetType(),
                    String.Format("Apress.Extensibility.Adapters.Resources.{0}.png", 
                    CheckBoxListControl.OffImage));
                img.ToolTip = String.Format("{0} (off) ", 
                    CheckBoxListControl.Items[i].Text);
            }
            l.Text = CheckBoxListControl.Items[i].Text;
            img.RenderControl(writer);
            l.RenderControl(writer);
        }

    }
}
