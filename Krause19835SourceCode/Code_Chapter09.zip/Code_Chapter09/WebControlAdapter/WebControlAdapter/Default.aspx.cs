﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.Adapters;

namespace WebControlAdapter
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        if (!IsPostBack)
        {
            var lic = new List<ListItem>();
            lic.Add(new ListItem("Value 1", "1") { Selected = true });
            lic.Add(new ListItem("Value 2", "2") { Selected = false });
            lic.Add(new ListItem("Value 3", "3") { Selected = true });
            lic.Add(new ListItem("Value 4", "4") { Selected = false });
            MyCheckBoxList1.Items.AddRange(lic.ToArray());
        }
        }


    }


}
