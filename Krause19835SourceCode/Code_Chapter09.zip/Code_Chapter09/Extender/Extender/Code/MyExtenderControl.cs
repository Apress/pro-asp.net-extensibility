﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

namespace Apress.Extensibility.Extender.Code
{

    [ProvideProperty("MagicProperty", typeof(Control))]
    public class DesignerProvider : Control, IExtenderProvider
    {

        private Dictionary<object, bool> _controls = new Dictionary<object, bool>();

        //public bool MagicProperty
        //{
        //    get;
        //    set;
        //}

        public bool GetMagicProperty(object extendee)
        {
            if (_controls.ContainsKey(extendee))
            {
                return _controls[extendee];
            }
            else
            {
                return false;
            }
        }

        public void SetMagicProperty(object extendee, bool val)
        {
            _controls[extendee] = val;
            if (val)
            {
                ((Control)extendee).PreRender += new EventHandler(DesignerProvider_PreRender);
            }
        }

        #region IExtenderProvider Members

        public void DesignerProvider_PreRender(object sender, EventArgs e)
        {
            ((MyExtenderControl) sender).Text += "?";
        }

        public bool CanExtend(object extendee)
        {
            if (extendee is MyExtenderControl)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        #endregion
    }


    [DefaultProperty("Text")]
    [ToolboxData("<{0}:MyExtenderControl runat=server></{0}:MyExtenderControl>")]
    public class MyExtenderControl : WebControl
    {
        [Bindable(true)]
        [Category("Appearance")]
        [DefaultValue("")]
        [Localizable(true)]
        public string Text
        {
            get
            {
                String s = (String)ViewState["Text"];
                return ((s == null) ? String.Empty : s);
            }

            set
            {
                ViewState["Text"] = value;
            }
        }

        protected override void RenderContents(HtmlTextWriter output)
        {
            output.Write(Text);
        }
    }
}
