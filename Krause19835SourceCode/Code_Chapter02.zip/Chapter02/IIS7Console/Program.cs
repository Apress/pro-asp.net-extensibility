﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Apress.AspNetExtensiblity.IIS7Console
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] arg = args;
            do
            {
                while (arg.Length == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Available Commands (not case sensitive): ");
                    Console.WriteLine("WP: Show Worker Processes");
                    Console.WriteLine("GR: Show Requests");
                    Console.WriteLine("UA <arg>: Unload Domain <arg>");
                    Console.WriteLine("UALL: Unload all Domains");
                    Console.WriteLine("SA: Show all AppDomain");
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    arg = new string[] { Console.ReadLine() };
                    Console.ForegroundColor = ConsoleColor.White;
                }
                // Usage instructions
                switch (arg[0].ToLower())
                {
                    default:
                    case "wp":
                        Console.WriteLine(IIS7Management.ShowWorkerProcesses());
                        break;
                    case "gr":
                        Console.WriteLine(IIS7Management.ShowRequest());
                        break;
                    case "ua":
                        if (args.Length != 2) throw new ArgumentException();
                        Console.WriteLine(IIS7Management.UnloadAppDomain(args[1]));
                        break;
                    case "uall":
                        Console.WriteLine(IIS7Management.UnloadAppDomains());
                        break;
                    case "sa":
                        Console.WriteLine(IIS7Management.ShowAppDomains());
                        break;
                }
                Console.WriteLine("Hit enter to repeat, X + Enter to close");
                arg = new string[0];
            } while (!Console.ReadLine().ToLower().Equals("x"));
        }
    }
}
