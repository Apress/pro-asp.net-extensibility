﻿using System;
using System.Linq;
using System.Text;
using Microsoft.Web.Administration;

namespace Apress.AspNetExtensiblity.IIS7Console
{
    static class IIS7Management
    {

        internal static string ShowWorkerProcesses()
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                ServerManager manager = new ServerManager();
                foreach (WorkerProcess proc in manager.WorkerProcesses)
                {
                    sb.AppendFormat("WorkerProcess found: {0}\n", proc.ProcessId);
                    sb.AppendFormat("\t|--AppPool : {0}\n", proc.AppPoolName);
                    sb.AppendFormat("\t|--ProcGuid: {0}\n", proc.ProcessGuid);
                    sb.AppendFormat("\t|--State   : {0}\n", proc.State.ToString());

                    foreach (ApplicationDomain appDom in proc.ApplicationDomains)
                    {
                        sb.AppendFormat(
                            "\t+--ApplicationDomain Found: {0}\n", appDom.Id);
                        sb.AppendFormat(
                            "\t\t|--AppDomPhysPath: {0}\n", appDom.PhysicalPath);
                        sb.AppendFormat(
                            "\t\t+--AppDomVirtPath: {0}\n", appDom.VirtualPath);
                    }
                }
                return sb.ToString();
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        internal static string ShowRequest()
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                ServerManager manager = new ServerManager();
                foreach (WorkerProcess proc in manager.WorkerProcesses)
                {
                    foreach (Request r in proc.GetRequests(0))
                    {
                        sb.AppendFormat("Request:\n");
                        sb.AppendFormat(" Hostname = {0}\n", r.HostName);
                        sb.AppendFormat(" Url = {0}\n", r.Url);
                        sb.AppendFormat(" Verb = {0}\n", r.Verb);
                        sb.AppendFormat(" IP = {0}\n", r.ClientIPAddr);
                    }
                }
                return sb.ToString();
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        internal static string UnloadAppDomain(string name)
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                sb.Append(ShowWorkerProcesses());
                ServerManager manager = new ServerManager();
                var appDomains = from proc in manager.WorkerProcesses
                                 from adc in proc.ApplicationDomains
                                 where adc.Id == "/LM/W3SVC/4/ROOT"
                                 select adc;

                ApplicationDomain ad = appDomains.FirstOrDefault<ApplicationDomain>();

                if (ad != null)
                {
                    ad.Unload();
                    return name + " unloaded";
                }
                else
                {
                    return "can't find " + name;
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        internal static string UnloadAppDomains()
        {
            try
            {
                ServerManager manager = new ServerManager();
                Func<ApplicationDomain, bool> unloadFunc = new Func<ApplicationDomain, bool>(Unload);
                var appDomains = from proc in manager.WorkerProcesses
                                 from adc in proc.ApplicationDomains
                                 where unloadFunc(adc) == true
                                 select adc;
                return "Unloaded " + appDomains.Count() + " domain(s)";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        private static bool Unload(ApplicationDomain appDomain)
        {
            try
            {
                appDomain.Unload();
                return true;
            }
            catch
            {
                return false;
            }
        }

        internal static string ShowAppDomains()
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                ServerManager manager = new ServerManager();
                var appDomains = from proc in manager.WorkerProcesses
                                 from adc in proc.ApplicationDomains
                                 select 
                                    String.Format(@"Physical Path = {0} 
                                                 {4}Virtual Path = {1} 
                                                 {4}Process ID = {2}
                                                 {4}Is Idle = {3}",                                          
                                         adc.PhysicalPath,
                                         adc.VirtualPath,
                                         adc.Id,
                                         adc.Idle,                                        
                                         Environment.NewLine);

                if (appDomains.Count() == 0)
                {
                    sb.Append("can't find AppDomains");
                }
                else
                {
                    foreach (string ad in appDomains)
                    {
                        sb.AppendLine(ad);
                    }
                }
                return sb.ToString();
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

    }
}