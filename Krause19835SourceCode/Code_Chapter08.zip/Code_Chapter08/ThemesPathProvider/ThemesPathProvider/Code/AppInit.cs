﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Hosting;
using Apress.Extensibility.PathProvider.ThemesProvider;

namespace Apress.Extensibility.PathProvider
{
    public static class AppStart
    {
        public static void AppInitialize()
        {
            HostingEnvironment.RegisterVirtualPathProvider(ThemePathProvider.Current);
        }
    }
}
