using System;
using System.IO;

namespace Apress.Extensibility.PathProvider.ThemesProvider
{
    public class VirtualThemeFile : System.Web.Hosting.VirtualFile
    {
        private String _themeAbsolutePath = String.Empty;
        private String _globalAbsolutePath = String.Empty;
        private VirtualThemeDirectory _parent = null;

        public VirtualThemeFile(String virtualPath,
            String themeAbsolutePath, 
            String globalAbsolutePath,
            VirtualThemeDirectory parent)
            : base(virtualPath)
        {
            _themeAbsolutePath = themeAbsolutePath;
            _globalAbsolutePath = globalAbsolutePath;
            _parent = parent;
        }

        public override Stream Open()
        {
            return File.Open(AbsolutePath, FileMode.Open);
        }

        public VirtualThemeDirectory Parent
        {
            get
            {
                return _parent;
            }
        }

        private String AbsolutePath
        {
            get
            {
                // Get the current set value
                String currentSet = ThemePathProvider.Current.CurrentSet;

                if ((!String.IsNullOrEmpty(_themeAbsolutePath))
                    && (Parent.FileIsIncluded(Name, currentSet, true)))
                    return _themeAbsolutePath;
                else if ((!String.IsNullOrEmpty(_globalAbsolutePath))
                    && (Parent.FileIsIncluded(Name, currentSet, false)))
                    return _globalAbsolutePath;

                return String.Empty;
            }
        }

        internal Boolean ExistsInThemeDirectory
        {
            get
            {
                return (!String.IsNullOrEmpty(_themeAbsolutePath));
            }
        }

        internal Boolean ExistsInGlobalDirectory
        {
            get
            {
                return (!String.IsNullOrEmpty(_globalAbsolutePath));
            }
        }
    }
}
