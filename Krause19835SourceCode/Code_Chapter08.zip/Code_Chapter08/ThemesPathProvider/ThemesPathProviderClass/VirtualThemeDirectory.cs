using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Hosting;

namespace Apress.Extensibility.PathProvider.ThemesProvider
{
    public class VirtualThemeDirectory : VirtualDirectory
    {
        struct ItemSearchInfo
        {
            public String Name;
            public String VirtualPath;
            public String ThemeAbsolutePath;
            public String GlobalAbsolutePath;
        }

        private VirtualThemeDirectory _parent = null;
        private String _themeAbsolutePath = String.Empty;
        private String _globalAbsolutePath = String.Empty;
        private Dictionary<String, VirtualThemeDirectory> _directories = null;
        private Dictionary<String, VirtualThemeFile> _files = null;
        private Dictionary<String, VirtualFileBase> _children = null;

        public VirtualThemeDirectory(String virtualPath)
            : this(virtualPath, String.Empty, String.Empty, null)
        {            
        }

        public VirtualThemeDirectory(String virtualPath,
            String themeAbsolutePath,
            String globalAbsolutePath)
            : this(virtualPath, themeAbsolutePath, globalAbsolutePath, null)
        {
        }

        public VirtualThemeDirectory(String virtualPath,
            String themeAbsolutePath,
            String globalAbsolutePath, 
            VirtualThemeDirectory parent)
            : base(virtualPath)
        {
            if (String.IsNullOrEmpty(themeAbsolutePath))
            {
                String sThemeRelativePath = ThemePathProvider.Current.ConvertToThemeRelativePath(VirtualPath);
                themeAbsolutePath = HttpContext.Current.Server.MapPath(sThemeRelativePath);
            }

            if (!Directory.Exists(themeAbsolutePath))
            {
                themeAbsolutePath = String.Empty;
            }
            if (String.IsNullOrEmpty(globalAbsolutePath))
            {
                String sGlobalRelativePath = ThemePathProvider.Current.ConvertToGlobalRelativePath(virtualPath);
                globalAbsolutePath = HttpContext.Current.Server.MapPath(sGlobalRelativePath);
            }

            if (!Directory.Exists(globalAbsolutePath))
                globalAbsolutePath = String.Empty;

            _themeAbsolutePath = themeAbsolutePath;
            _globalAbsolutePath = globalAbsolutePath;

            _parent = parent;

            // Create the collections to hold the virtual items
            _files = new Dictionary<string, VirtualThemeFile>();
            _directories = new Dictionary<string, VirtualThemeDirectory>();
            _children = new Dictionary<string, VirtualFileBase>();

            FindFiles();
            FindSubDirectories();
            FindChildren();
        }
        
        private void FindFiles()
        {
            Dictionary<String, ItemSearchInfo> fileList = new Dictionary<string, ItemSearchInfo>();
            if (Directory.Exists(ThemeAbsolutePath))
            {
                var files = from f in Directory.GetFiles(ThemeAbsolutePath)
                            select new ItemSearchInfo
                            {
                                Name = Path.GetFileName(f),
                                VirtualPath = VirtualPathUtility.Combine(VirtualPath, Path.GetFileName(f)),
                                ThemeAbsolutePath = f
                            };
                foreach (ItemSearchInfo fileInfo in files)
                {
                    fileList.Add(fileInfo.Name, fileInfo);
                }
            }

            if (Directory.Exists(GlobalAbsolutePath))
            {
                var files = from f in Directory.GetFiles(GlobalAbsolutePath)
                            select new ItemSearchInfo
                            {
                                Name = Path.GetFileName(f),
                                VirtualPath = VirtualPathUtility.Combine(VirtualPath, Path.GetFileName(f)),
                                GlobalAbsolutePath = f
                            };

                foreach (ItemSearchInfo fileInfo in files)
                {
                    if (fileList.ContainsKey(fileInfo.Name))
                    {
                        ItemSearchInfo themeFileInfo = fileList[fileInfo.Name];
                        fileList.Remove(themeFileInfo.Name);
                        fileList.Add(themeFileInfo.Name, themeFileInfo);
                    }
                    else
                    {
                        fileList.Add(fileInfo.Name, fileInfo);
                    }
                }
            }

            // Loop through each file found
            foreach (ItemSearchInfo fileInfo in fileList.Values)
            {
                // Add each file to the files dictionary using the information stored for the file
                _files.Add(fileInfo.Name, new VirtualThemeFile(fileInfo.VirtualPath, fileInfo.ThemeAbsolutePath, fileInfo.GlobalAbsolutePath, this));
            }            
        }

        private void FindSubDirectories()
        {
            Dictionary<String, ItemSearchInfo> directoryList = new Dictionary<string, ItemSearchInfo>();
            Func<string, string, string> MakePath = delegate(string b, string v)
            {
                return VirtualPathUtility.AppendTrailingSlash(VirtualPathUtility.Combine(b, v));
            };
            if (Directory.Exists(ThemeAbsolutePath))
            {
                var themeDirectories = from t in Directory.GetDirectories(ThemeAbsolutePath)
                            select new ItemSearchInfo
                            {
                                Name = Path.GetFileName(t),
                                VirtualPath = MakePath(VirtualPath, Path.GetFileName(t)),
                                ThemeAbsolutePath = t
                            };

                foreach (ItemSearchInfo directoryInfo in themeDirectories)
                {
                    directoryList.Add(directoryInfo.Name, directoryInfo);
                }
            }
            if (Directory.Exists(GlobalAbsolutePath))
            {
                var themeDirectories = from t in Directory.GetDirectories(GlobalAbsolutePath)
                            select new ItemSearchInfo
                            {
                                Name = Path.GetFileName(t),
                                VirtualPath = MakePath(VirtualPath, Path.GetFileName(t)),
                                GlobalAbsolutePath = t
                            };

                foreach (ItemSearchInfo directoryInfo in themeDirectories)
                {
                    if (directoryList.ContainsKey(directoryInfo.Name))
                    {
                        ItemSearchInfo themeDirectoryInfo = directoryList[directoryInfo.Name];
                        directoryList.Remove(themeDirectoryInfo.Name);
                        directoryList.Add(themeDirectoryInfo.Name, themeDirectoryInfo);
                    }
                    else
                    {
                        directoryList.Add(directoryInfo.Name, directoryInfo);
                    }
                }
            }
            foreach (ItemSearchInfo directoryInfo in directoryList.Values)
            {
                VirtualThemeDirectory directory = new VirtualThemeDirectory(directoryInfo.VirtualPath, directoryInfo.ThemeAbsolutePath, directoryInfo.GlobalAbsolutePath, this);
                _directories.Add(directory.Name, directory);
            }
        }

        private void FindChildren()
        {
            foreach (VirtualThemeDirectory directory in Directories)
            {
                _children.Add(directory.Name, directory);
            }
            foreach (VirtualThemeFile file in Files)
            {
                _children.Add(file.Name, file);
            }
        }

        public Boolean GetFileIsIncluded(String fileName)
        {
            String currentSet = ThemePathProvider.Current.CurrentSet;
            if (FileIsIncluded(fileName, currentSet, true))
            {
                return true;
            }
            else
            {
                return FileIsIncluded(fileName, currentSet, false);
            }
        }

        public Boolean GetDirectoryIsIncluded(String directoryName)
        {
            String currentSet = ThemePathProvider.Current.CurrentSet;
            if (DirectoryIsIncluded(directoryName, currentSet, true))
            {
                return true;
            }
            else
            {
                return DirectoryIsIncluded(directoryName, currentSet, false);
            }
        }

        internal Boolean FileIsIncluded(String fileName, String currentSet, Boolean checkAgainstTheme)
        {
            if (!_files.ContainsKey(fileName))
                return false;
            VirtualThemeFile file = _files[fileName];
            if ((checkAgainstTheme)
                && (file.ExistsInThemeDirectory == false))
            {
                return false;
            }
            else if ((!checkAgainstTheme)
                && (!file.ExistsInGlobalDirectory))
            {
                return false;
            }
            if (String.IsNullOrEmpty(currentSet))
                return true;
            String fileExtension = Path.GetExtension(fileName);
            if (fileExtension.ToUpper() == ".SKIN"
                ||
                fileExtension.ToUpper() == ".CSS"
                ||
                fileExtension.ToUpper() == ".JPG")
            {
                return true;
            }
            return false;
        }

        internal Boolean DirectoryIsIncluded(String directoryName, String currentSet, Boolean checkAgainstTheme)
        {
            if (!_directories.ContainsKey(directoryName))
                return false;
            VirtualThemeDirectory directory = _directories[directoryName];
            if ((checkAgainstTheme)
                && (!directory.ExistsInThemeDirectory))
            {
                return false;
            }
            else if ((!checkAgainstTheme)
                && (!directory.ExistsInGlobalDirectory))
            {
                return false;
            }
            if (String.IsNullOrEmpty(currentSet))
                return true;
            return true;
        }

        internal VirtualThemeFile GetFile(String fileName)
        {
            return _files[fileName];
        }

        internal VirtualThemeDirectory GetDirectory(String virtualDir)
        {
            if (_directories.Count == 0)
                return null;
            if (virtualDir.StartsWith(VirtualPath, StringComparison.InvariantCultureIgnoreCase) == false)
                return null;
            String relativeVirtualPath = virtualDir.Substring(VirtualPath.Length);
            String directoryName = relativeVirtualPath.Substring(0, relativeVirtualPath.IndexOf("/"));
            VirtualThemeDirectory childDirectory = _directories[directoryName];
            if (childDirectory.VirtualPath == virtualDir)
                return childDirectory;
            else
                return childDirectory.GetDirectory(virtualDir);
        }
        
        public VirtualThemeDirectory Parent
        {
            get
            {
                return _parent;
            }
        }

        public Boolean Exists
        {
            get
            {
                return ((Directory.Exists(_themeAbsolutePath) == true)
                    || (Directory.Exists(_globalAbsolutePath) == true));
            }
        }

        private Boolean ExistsInThemeDirectory
        {
            get
            {
                return (String.IsNullOrEmpty(_themeAbsolutePath) == false);
            }
        }

        private Boolean ExistsInGlobalDirectory
        {
            get
            {
                return (String.IsNullOrEmpty(_globalAbsolutePath) == false);
            }
        }

        public override IEnumerable Directories
        {
            get
            {
                return _directories.Values;
            }
        }

        public override IEnumerable Files
        {
            get
            {
                return _files.Values;
            }
        }

        public override IEnumerable Children
        {
            get
            {
                return _children.Values;
            }
        }

        private String ThemeAbsolutePath
        {
            get
            {
                return _themeAbsolutePath;
            }
        }

        private String GlobalAbsolutePath
        {
            get
            {
                return _globalAbsolutePath;
            }
        }

    }
}
