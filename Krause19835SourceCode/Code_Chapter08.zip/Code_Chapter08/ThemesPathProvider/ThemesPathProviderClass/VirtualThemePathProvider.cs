using System;
using System.Configuration;
using System.Web;
using System.Web.Hosting;
using System.Collections.Specialized;
using System.Web.Configuration;
using System.IO;

namespace Apress.Extensibility.PathProvider.ThemesProvider
{
    public sealed class ThemePathProvider : VirtualPathProvider
    {
        private static ThemePathProvider _currentProvider = null;
        private const string ASPNetThemeBasePath = "/App_Themes/";
        private string _themeRelativePath = String.Empty;
        private string _currentThemeSet = String.Empty;
        private string _globalThemeName = String.Empty;

        private ThemePathProvider()
        {
            _themeRelativePath = WebConfigurationManager.AppSettings["CustomThemeBasePath"];
        }

        public override System.Web.Caching.CacheDependency GetCacheDependency(string virtualPath, System.Collections.IEnumerable virtualPathDependencies, DateTime utcStart)
        {
            return null;
        }
        
        public override bool DirectoryExists(string virtualDir)
        {
            if (virtualDir.IndexOf(ASPNetThemeBasePath) == -1)
                return base.DirectoryExists(virtualDir);
            VirtualThemeDirectory directory = GetDirectory(virtualDir) as VirtualThemeDirectory;
            return directory.Exists;
        }

        public override bool FileExists(string virtualPath)
        {
            if (virtualPath.IndexOf(ASPNetThemeBasePath) == -1)
                return base.FileExists(virtualPath);
            string fileName = System.Web.VirtualPathUtility.GetFileName(virtualPath);
            string virtualDirectoryPath = System.Web.VirtualPathUtility.GetDirectory(virtualPath);
            VirtualThemeDirectory directory = GetDirectory(virtualDirectoryPath) as VirtualThemeDirectory;
            return directory.GetFileIsIncluded(fileName);
        }

        public override VirtualDirectory GetDirectory(string virtualDir)
        {
            if (virtualDir.IndexOf(ASPNetThemeBasePath) == -1)
                return base.GetDirectory(virtualDir);
            if (IsThemeDirectoryVirtualPath(virtualDir))
            {
                return new VirtualThemeDirectory(virtualDir);
            }
            else
            {
                String themeVirtualPath = GetThemeDirectoryVirtualPath(virtualDir);
                VirtualThemeDirectory directory = new VirtualThemeDirectory(virtualDir);
                return directory.GetDirectory(virtualDir);
            }
        }

        public override VirtualFile GetFile(string virtualPath)
        {
            if (virtualPath.IndexOf(ASPNetThemeBasePath) == -1)
                return base.GetFile(virtualPath);
            String virtualDirectoryPath = System.Web.VirtualPathUtility.GetDirectory(virtualPath);
            VirtualThemeDirectory directory = GetDirectory(virtualDirectoryPath) as VirtualThemeDirectory;
            String fileName = System.Web.VirtualPathUtility.GetFileName(virtualPath);
            return directory.GetFile(fileName);
        }

        private StringCollection GetDependentDirectories(
            String parentDirectoryPath,
            StringCollection dependentPaths)
        {
            String[] directories = Directory.GetDirectories(parentDirectoryPath);
            for (int loopIndex = 0; loopIndex < directories.Length; loopIndex++)
            {
                dependentPaths.Add(directories[loopIndex]);
                GetDependentDirectories(directories[loopIndex], dependentPaths);
            }
            return dependentPaths;
        }

        private Boolean IsThemeDirectoryVirtualPath(String virtualPath)
        {
            String parentVirtualPath = System.Web.VirtualPathUtility.GetDirectory(virtualPath);
            return parentVirtualPath.EndsWith(ASPNetThemeBasePath, StringComparison.InvariantCultureIgnoreCase);
        }

        private String GetThemeDirectoryVirtualPath(String virtualPath)
        {
            String parentVirtualPath = System.Web.VirtualPathUtility.GetDirectory(virtualPath);
            while (!IsThemeDirectoryVirtualPath(parentVirtualPath))
            {
                parentVirtualPath = System.Web.VirtualPathUtility.GetDirectory(parentVirtualPath);
            }
            return parentVirtualPath;
        }

        internal String ConvertToThemeRelativePath(String relativePath)
        {
            return ConvertToThemeNameRelativePath(relativePath, false);
        }

        internal String ConvertToGlobalRelativePath(String relativePath)
        {
            return ConvertToThemeNameRelativePath(relativePath, true);
        }

        private String ConvertToThemeNameRelativePath(String relativePath, Boolean replaceThemeNameWithGlobal)
        {
            String themeNameRelativePath = String.Empty;
            if ((!relativePath.StartsWith(ASPNetThemeBasePath))
                && (!_themeRelativePath.StartsWith("/")))
            {
                themeNameRelativePath = relativePath.Substring(0, relativePath.IndexOf(ASPNetThemeBasePath));
            }

            if ((!themeNameRelativePath.EndsWith("/"))
                && (!_themeRelativePath.StartsWith("/")))
            {
                themeNameRelativePath = System.Web.VirtualPathUtility.AppendTrailingSlash(themeNameRelativePath);
            }

            themeNameRelativePath += _themeRelativePath;

            String remainderPath = relativePath.Substring(relativePath.IndexOf(ASPNetThemeBasePath) + ASPNetThemeBasePath.Length);

            if (replaceThemeNameWithGlobal)
            {
                remainderPath = remainderPath.Substring(remainderPath.IndexOf("/"));
            }
            themeNameRelativePath += remainderPath;

            return themeNameRelativePath;
        }

        public static ThemePathProvider Current
        {
            get
            {
                if (_currentProvider != null)
                    return _currentProvider;

                _currentProvider = new ThemePathProvider();
                return _currentProvider;
            }
        }

        public String CurrentSet
        {
            get
            {
                return _currentThemeSet;
            }
            set
            {
                _currentThemeSet = value;
            }
        }
    }
}
