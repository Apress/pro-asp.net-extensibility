﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Hosting;

namespace Apress.Extensibility.PathProvider
{
    public static class AppStart
    {
        public static void AppInitialize()
        {
            UcPathProvider customProvider = new UcPathProvider();
            HostingEnvironment.RegisterVirtualPathProvider(customProvider);
        }
    }
}

