﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Hosting;

namespace Apress.Extensibility.PathProvider
{
    public class UcPathProvider : VirtualPathProvider
    {
        public override string CombineVirtualPaths(string basePath, string relativePath)
        {

            throw new Exception("ll");

            // If the path is relative, let normal processing happen 
            if (!VirtualPathUtility.IsAbsolute(relativePath))
                return base.CombineVirtualPaths(basePath, relativePath);

            // Determine the pseudo site from the request.  To demonstrate, we just get it from the 
            // query string, but it could come from other places, like the http host header 
            string site = HttpContext.Current.Request.QueryString["site"];

            // If we couldn't, default to normal processing 
            if (site == null)
                return base.CombineVirtualPaths(basePath, relativePath);

            // Make it app relative (i.e. ~/...) 
            relativePath = VirtualPathUtility.ToAppRelative(relativePath);

            // Remap the virtual path to be inside the correct pseudo site 
            return "~/PseudoSites/" + site + relativePath.Substring(1);

        }
    }
}
