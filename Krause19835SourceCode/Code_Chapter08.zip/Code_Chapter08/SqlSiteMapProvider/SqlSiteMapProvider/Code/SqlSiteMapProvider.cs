﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration.Provider;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Permissions;
using System.Web;
using System.Web.Configuration;

namespace Apress.Extensibility.SqlSiteMap
{

    [SqlClientPermission(SecurityAction.Demand, Unrestricted = true)]
    public class SqlSiteMapProvider : StaticSiteMapProvider
    {
        private string _connect;
        private int _indexNode;
        private int _indexTitle; 
        private int _indexUrl;
        private int _indexDesc;
        private int _indexRoles;
        private int _indexParent;
        private int _indexRoot;

        private SiteMapNode _root;
        private Dictionary<string, SiteMapNode> _nodes = new Dictionary<string, SiteMapNode>(16);

        public override void Initialize(string name, NameValueCollection config)
        {
            if (config == null)
                throw new ArgumentNullException("config");
            if (String.IsNullOrEmpty(name))
                name = "SqlSiteMapProvider";

            base.Initialize(name, config);
            string connect = "siteMap";
            if (WebConfigurationManager.ConnectionStrings[connect] == null)
                throw new ProviderException("No connection");
            _connect = WebConfigurationManager.ConnectionStrings[connect].ConnectionString;
            if (String.IsNullOrEmpty(_connect))
                throw new ProviderException("no connection string");
        }

        public override SiteMapNode BuildSiteMap()
        {
            lock (this)
            {
                if (_root != null)
                    return _root;
                SqlConnection connection = new SqlConnection(_connect);
                try
                {
                    connection.Open();
                    SqlCommand command;
                    command = new SqlCommand(
                       @"SELECT *, SiteMapNode.ToString() AS SiteMapNodeString, 
                   SiteMapNode.GetAncestor(1).ToString() AS Parent, 
                   hierarchyid::GetRoot().ToString() AS Root 
                   FROM aspnet_Navigation", connection);
                    command.CommandType = CommandType.Text;
                    SqlDataReader reader = command.ExecuteReader();
                    _indexNode = reader.GetOrdinal("SiteMapNodeString");
                    _indexUrl = reader.GetOrdinal("Url");
                    _indexTitle = reader.GetOrdinal("Title");
                    _indexDesc = reader.GetOrdinal("Description");
                    _indexRoles = reader.GetOrdinal("Roles");
                    _indexParent = reader.GetOrdinal("Parent");
                    _indexRoot = reader.GetOrdinal("Root");
                    string parentKey;
                    if (reader.Read())
                    {
                        _root = CreateSiteMapNode(reader, true, out parentKey);
                        AddNode(_root, null);
                        while (reader.Read())
                        {
                            SiteMapNode node = CreateSiteMapNode(reader, false, out parentKey);
                            SiteMapNode parent = GetParentSiteMapNode(parentKey);
                            AddNode(node, parent);
                        }
                    }
                }
                finally
                {
                    connection.Close();
                }
                return _root;
            }
        }

        protected override SiteMapNode GetRootNodeCore()
        {
            BuildSiteMap();
            return _root;
        }

        private SiteMapNode CreateSiteMapNode(DbDataReader reader, bool forRoot, out string parentKey)
        {
            string nodeString = reader.GetString(forRoot ? _indexRoot : _indexNode);
            string title = reader.IsDBNull(_indexTitle) ? null : reader.GetString(_indexTitle).Trim();
            string url = reader.IsDBNull(_indexUrl) ? null : reader.GetString(_indexUrl).Trim();
            string description = reader.IsDBNull(_indexDesc) ? null : reader.GetString(_indexDesc).Trim();
            string roles = reader.IsDBNull(_indexRoles) ? null : reader.GetString(_indexRoles).Trim();
            string[] rolelist = null;
            if (!String.IsNullOrEmpty(roles))
                rolelist = roles.Split(new char[] { ',', ';' }, 512);
            SiteMapNode node = new SiteMapNode(this, nodeString,
                                               url,
                                               title,
                                               description,
                                               rolelist, null, null, null);
            parentKey = reader.IsDBNull(_indexParent) ? null : reader.GetString(_indexParent);   
            _nodes.Add(nodeString, node);
            return node;
        }

        private SiteMapNode GetParentSiteMapNode(string parentKey)
        {
            var parent = from n in _nodes where n.Key.Equals(parentKey) select n.Value;
            return parent.FirstOrDefault<SiteMapNode>();
        }


    }
}