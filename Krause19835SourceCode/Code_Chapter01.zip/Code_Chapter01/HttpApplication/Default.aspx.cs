﻿using System;
using System.Threading;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using System.Xml.Linq;

namespace Chapter1_HttpApplication
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Guid appId = ((Global) Context.ApplicationInstance).AppId;
            this.appId.Text = appId.ToString();
            this.threadId.Text = Thread.CurrentThread.ManagedThreadId.ToString();
            this.domainId.Text = AppDomain.CurrentDomain.FriendlyName;
            this.threadInfo.Text = Thread.CurrentThread.IsThreadPoolThread ? "Pool Thread" : "No Thread";
            this.threadApart.Text = Thread.CurrentThread.GetApartmentState().ToString();
            Thread.Sleep(4000);
        }
    }
}