﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        DateTime.Now.ToLongDateString();
    }
    protected void GridView1_Init(object sender, EventArgs e)
    {
        Response.Write("Grid::Init<br>");
    }
    protected void GridView1_Load(object sender, EventArgs e)
    {
        Response.Write("Grid::Load<br>");
    }
    protected void GridView1_PreRender(object sender, EventArgs e)
    {
        Response.Write("Grid::PreRender<br>");
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        Response.Write("Grid::RowDataBound<br>");
    }
    protected void GridView1_DataBound(object sender, EventArgs e)
    {
        Response.Write("Grid::DataBound<br>");
    }
    protected void GridView1_DataBinding(object sender, EventArgs e)
    {
        Response.Write("Grid::DataBinding<br>");
    }

    protected void Label1_Load(object sender, EventArgs e)
    {
        Response.Write("Label::Load<br>");
    }
    protected void Label1_Init(object sender, EventArgs e)
    {
        Response.Write("Label::Init<br>");
    }
    protected void Label1_DataBinding(object sender, EventArgs e)
    {
        Response.Write("Label::DataBinding<br>");
    }
    protected void Label1_PreRender(object sender, EventArgs e)
    {
        Response.Write("Label::PreRender<br>");
    }

    protected void ddCommand_Load(object sender, EventArgs e)
    {
        Response.Write("ddCommand::Load<br>");
    }
    protected void ddCommand_Init(object sender, EventArgs e)
    {
        Response.Write("ddCommand::Init<br>");
    }
    protected void ddCommand_DataBinding(object sender, EventArgs e)
    {
        Response.Write("ddCommand::DataBinding<br>");
    }
    protected void ddCommand_PreRender(object sender, EventArgs e)
    {
        Response.Write("ddCommand::PreRender<br>");
    }

    public List<string> Values
    {
        get
        {
            return new List<string>(new string[] { "Show", "Buy", "Sell" });
        }
    }

}
