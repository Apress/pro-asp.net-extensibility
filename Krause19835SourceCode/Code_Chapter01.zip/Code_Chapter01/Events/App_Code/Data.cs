﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Data
/// </summary>
public class Data
{
    public Data()
    {
    }
    public List<string> GetValues()
    {
        return new List<string>(new string[] { "Show", "Buy", "Sell" });
    }

}