﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;

namespace Apress.Extensibility.RequestEvent
{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {

        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {
            if (true)
            {
                Context.Items.Add("LogTime", DateTime.Now);
            }
        }

        protected void Application_EndRequest(object sender, EventArgs e)
        {
            if (true)
            {
                DateTime end = DateTime.Now;
                TimeSpan span = end.Subtract((DateTime) Context.Items["LogTime"]);
                System.Diagnostics.Debug.WriteLine(span.TotalMilliseconds, "RequestTime");
            }
        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}