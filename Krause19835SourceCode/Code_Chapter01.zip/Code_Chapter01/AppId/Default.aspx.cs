﻿using System;
using System.Threading;

namespace Apress.Extensibility.AppDomains
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Guid id = ((Global)Context.ApplicationInstance).AppId;
            this.appId.Text = id.ToString();
            this.threadId.Text = Thread.CurrentThread.ManagedThreadId.ToString();
            this.domainId.Text = AppDomain.CurrentDomain.FriendlyName;
            this.threadInfo.Text = Thread.CurrentThread.IsThreadPoolThread ?
                                   "Pool Thread" : "No Thread";
            this.threadApart.Text = Thread.CurrentThread.GetApartmentState().ToString();
            Thread.Sleep(4000);

        }
    }
}
