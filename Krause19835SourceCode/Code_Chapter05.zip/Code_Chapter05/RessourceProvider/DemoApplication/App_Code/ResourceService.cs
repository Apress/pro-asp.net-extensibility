using System;
using System.Xml;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Web.Script.Services;
using System.IO;
using System.Resources;
using System.Data;
using System.Reflection;
using System.Web.Compilation;
using System.Globalization;
using Apress.Extensibility.Resources.Localization;
using System.Collections.Generic;

namespace ResxEditor
{

    [ScriptService()]
    [WebService(Namespace = "http://www.apress.com/extensibility")]
    [GenerateScriptType(typeof(Cultures))]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class ResourceService : System.Web.Services.WebService
    {

        private XmlDocument rr = new XmlDocument();
        private ResourceManager rm;
        CustomResourceProviderFactory rf;

        public ResourceService()
        {
            // get assembly where the resources reside
            Assembly resAssembly = typeof(CustomResourceProviderFactory).Assembly;
            rm = new ResourceManager("Computacenter.ResourceProvider", resAssembly);
            rf = new CustomResourceProviderFactory();
        }


        [WebMethod()]
        public Cultures GetAllLanguages()
        {
            List<CultureInfo> cList = (List<CultureInfo>)Application["cultures"];
            Cultures c = new Cultures(cList.Count);
            for (int i = 0; i < cList.Count; i++)
            {
                c.cultureName[i] = cList[i].DisplayName;
                c.cultureID[i] = cList[i].Name;
            }
            return c;
        }

        /// <summary>
        /// Load resource and send to sevice.
        /// </summary>
        /// <param name="pageId"></param>
        /// <param name="ctrlId"></param>
        /// <param name="allowHtml"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        [WebMethod()]
        public string LoadResource(string pageId, string ctrlId, string culture, string theme)
        {
            pageId = pageId.Replace("~", "");
            rf.Theme = theme;
            IResourceProvider rp = rf.CreateLocalResourceProvider(pageId);
            object value = ((CustomResourceProvider)rp).GetResxObject(ctrlId, new CultureInfo(culture));
            return (value == null) ? String.Empty : value.ToString();
        }

        /// <summary>
        /// Save resource from online editor to webservice.
        /// </summary>
        /// <param name="pageId"></param>
        /// <param name="ctrlId"></param>
        /// <param name="content"></param>
        /// <param name="culture"></param>
        [WebMethod()]
        public void SaveResource(string pageId, string ctrlId, string content, string culture, string theme)
        {
            pageId = pageId.Replace("~", "");
            rf.Theme = theme;
            IResourceProvider rp = rf.CreateLocalResourceProvider(pageId);
            CultureInfo ci = new CultureInfo(culture);
            ((CustomResourceProvider)rp).GetResourceWriterForCulture(ci).AddResource(ctrlId, content);

        }

    }

    /// <summary>
    /// Class to handover server side culture definitions to Javascript part via webservice.
    /// </summary>
    [Serializable()]
    public class Cultures
    {
        /// <summary>
        /// Default ctor with two values
        /// </summary>
        public Cultures() : this(2)
        {
        }

        /// <summary>
        /// Pre create arrays to keep culture info
        /// </summary>
        /// <param name="len"></param>
        public Cultures(int len)
        {
            this.len = len;
            cultureName = new string[len];
            cultureID = new string[len];
        }

        /// <summary>
        /// Display name
        /// </summary>
        public string[] cultureName;
        /// <summary>
        /// ID in format ("de-de")
        /// </summary>
        public string[] cultureID;
        /// <summary>
        /// Number of elements to get easy access to element using for loops.
        /// </summary>
        public int len;
    }
}