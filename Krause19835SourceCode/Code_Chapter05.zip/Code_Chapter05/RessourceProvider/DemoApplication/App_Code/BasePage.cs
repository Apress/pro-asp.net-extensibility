﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Threading;
using System.Globalization;
using System.Web.Compilation;
using System.Collections;
using System.Resources;
using System.Collections.Specialized;

/// <summary>
/// Summary description for BasePage
/// </summary>
public class BasePage : Page
{
    private const string PREFIX = "$resources:";

    /// <summary>
    /// Using this we can set the parent master programmatically.
    /// </summary>
    /// <param name="e"></param>
    protected override void OnPreInit(EventArgs e)
    {
        base.OnPreInit(e);
        // Set Editor (special handling beyound the domain scope)
        if (Request.QueryString["e"] != null && Request.QueryString["e"] == "on")
        {
            Session["Editor"] = true;
        }
        if (Request.QueryString["e"] != null && Request.QueryString["e"] == "off")
        {
            Session["Editor"] = null;
        }
        string domain = Request.Url.Host;
        // Set Dynamic Theming and Master Pages
        if (Session["Editor"] != null)
        {
            Master.MasterPageFile = "editor.master";
        }
        else
        {
            Master.MasterPageFile = "default.master";
        }
        if (Session["theme"] != null)
        {
            Theme = Session["theme"] as string;
        }
        InitializeCulture();
    }

    /// <summary>
    /// Overriding the InitializeCulture method to set the user selected
    /// option in the current thread. Note that this method is called much
    /// earlier in the Page lifecycle and we don't have access to any controls
    /// in this stage, so have to use Form collection.
    /// </summary>
    protected override void InitializeCulture()
    {
        if (Session["culture"] != null)
        {
            string selectedCulture = Session["culture"] as string;
            if (!String.IsNullOrEmpty(selectedCulture))
            {
                SetCulture(selectedCulture);
            }
        }
        base.InitializeCulture();
    }

    /// <summary>
    /// Sets the current UICulture and CurrentCulture based on
    /// the arguments
    /// </summary>
    /// <param name="name"></param>
    /// <param name="locale"></param>
    protected void SetCulture(string name)
    {
        CultureInfo ci = new CultureInfo(name);
        Page.Culture = ci.Name;
        Thread.CurrentThread.CurrentUICulture = ci;
        Thread.CurrentThread.CurrentCulture = ci;
    }

    public object GetResourceObject(object resourceName)
    {
        if (resourceName != null)
        {
            string resString = resourceName.ToString();
            if (!String.IsNullOrEmpty(resString))
            {
                if (resString.StartsWith(PREFIX))
                {
                    resString = resString.Remove(0, PREFIX.Length);
                    return GetGlobalResourceObject(
                        resString.Split(",".ToCharArray())[0],
                        resString.Split(",".ToCharArray())[1]);
                }
            }
        }
        // not found
        return String.Empty;
    }


}