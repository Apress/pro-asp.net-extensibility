﻿using System.Collections.Generic;
using System.ServiceModel;
using System.Web.Security;

namespace Apress.Extensibility.Membership
{
    [ServiceContract]
    public interface IMembershipService
    {

        [OperationContract]
        bool ChangePassword(string username, string oldPassword, string newPassword);

        [OperationContract ]
        bool ChangePasswordQuestionAndAnswer(string username, string password, string newPasswordQuestion, string newPasswordAnswer);

        [OperationContract]
        User CreateUser(string username, string password, string email, string passwordQuestion, string passwordAnswer, bool isApproved, object providerUserKey, out MembershipCreateStatus status);

        [OperationContract]
        bool DeleteUser(string username, bool deleteAllRelatedData);

        [OperationContract]
        List<User> FindUsersByEmail(string emailToMatch, int pageIndex, int pageSize, out int totalRecords);

        [OperationContract]
        List<User> FindUsersByName(string usernameToMatch, int pageIndex, int pageSize, out int totalRecords);

        [OperationContract]
        List<User> GetAllUsers(int pageIndex, int pageSize, out int totalRecords);

        [OperationContract]
        int GetNumberOfUsersOnline();

        [OperationContract]
        string GetPassword(string username, string answer);

        [OperationContract(Name = "GetUserbyName")]
        User GetUser(string username, bool userIsOnline);

        [OperationContract]
        string GetUserNameByEmail(string email);

        [OperationContract]
        string ResetPassword(string username, string answer);

        [OperationContract]
        bool UnlockUser(string userName);

        [OperationContract]
        void UpdateUser(User user);

        [OperationContract]
        bool ValidateUser(string username, string password);

    }
}
