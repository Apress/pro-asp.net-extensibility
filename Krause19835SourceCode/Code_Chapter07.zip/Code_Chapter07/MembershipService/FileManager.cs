﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Security.Permissions;
using System.Text;
using System.Xml.Serialization;

namespace Apress.Extensibility.Membership
{
    internal static class FileManager
    {
        private const string DATAPATH = "App_Data\\UserData.xml";
        private static readonly string dataPath;
        private static object locker = new object();

        static FileManager()
        {
            Uri codeUri = new Uri(typeof(UserData).Assembly.CodeBase);
            dataPath = Path.Combine(Directory.GetParent(Path.GetDirectoryName(codeUri.LocalPath)).FullName, DATAPATH);
            // check file permissions
            FileIOPermission permission = new FileIOPermission(FileIOPermissionAccess.AllAccess, dataPath);
            permission.Demand();
        }

        internal static UserData Load()
        {
            lock (locker)
            {
                XmlSerializer xs = new XmlSerializer(typeof(UserData));
                UserData ud = null;
                try
                {
                    using (FileStream fs = new FileStream(dataPath, FileMode.Open))
                    {
                        ud = xs.Deserialize(fs) as UserData;
                    }
                }
                catch
                {
                    // save rudimentary format
                    ud = new UserData();
                    Save(ud);
                }
                return ud;
            }
        }

        internal static void Save(UserData ud)
        {
            lock (locker)
            {
                XmlSerializer xs = new XmlSerializer(typeof(UserData));
                using (FileStream fs = new FileStream(dataPath, FileMode.Create))
                {
                    xs.Serialize(fs, ud);
                }
            }
        }

        internal static string CalculateSHA1(string text)
        {
            byte[] buffer = Encoding.ASCII.GetBytes(text);
            SHA1CryptoServiceProvider cryptoTransformSHA1 = new SHA1CryptoServiceProvider();
            string hash = BitConverter.ToString(cryptoTransformSHA1.ComputeHash(buffer));
            return hash;
        }


    }
}
