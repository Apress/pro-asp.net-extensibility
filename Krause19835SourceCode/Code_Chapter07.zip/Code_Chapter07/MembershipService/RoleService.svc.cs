﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Apress.Extensibility.Membership
{
    // NOTE: If you change the class name "IRoleService" here, you must also update the reference to "IRoleService" in Web.config.
    public class RoleService : IRoleService
    {
        public void AddUsersToRoles(string[] usernames, string[] roleNames)
        {
            UserData ud = FileManager.Load();
            var users = (from u in ud.Users
                         where usernames.Contains(u.UserName)
                         select u);
            foreach (User user in users)
            {
                user.Roles.RemoveAll(role => roleNames.Contains(role));
                user.Roles.AddRange(roleNames);
            }
            FileManager.Save(ud);
        }

        public void CreateRole(string roleName)
        {
            UserData ud = FileManager.Load();
            if (!ud.Roles.Contains(roleName))
            {
                ud.Roles.Add(roleName);
                FileManager.Save(ud);
            }
        }

        public bool DeleteRole(string roleName, bool throwOnPopulatedRole)
        {
            UserData ud = FileManager.Load();
            var userInRole = from u in ud.Users where u.Roles.Contains(roleName) select u;
            if (userInRole.Count() > 0 && throwOnPopulatedRole)
            {
                return false;
            }
            ud.Roles.Remove(roleName);
            FileManager.Save(ud);
            return true;
        }

        public string[] FindUsersInRole(string roleName, string usernameToMatch)
        {
            UserData ud = FileManager.Load();
            var userInRole = from u in ud.Users 
                             where u.UserName.Contains(usernameToMatch) && u.Roles.Contains(roleName) 
                             select u.UserName;
            return userInRole.ToArray<string>();
        }

        public string[] GetAllRoles()
        {
            UserData ud = FileManager.Load();
            var roles = from r in ud.Roles select r;
            return roles.ToArray<string>();
        }

        public string[] GetRolesForUser(string username)
        {
            UserData ud = FileManager.Load();
            var roles = (from u in ud.Users
                         where u.UserName.Equals(username) 
                         select u.Roles).First();
            return roles.ToArray();
        }

        public string[] GetUsersInRole(string roleName)
        {
            UserData ud = FileManager.Load();
            var roles = (from u in ud.Users
                         where u.Roles.Contains(roleName)
                         select u.UserName);
            return roles.ToArray();
        }

        public bool IsUserInRole(string username, string roleName)
        {
            UserData ud = FileManager.Load();
            var roles = (from u in ud.Users
                         where u.UserName.Equals(username) && u.Roles.Contains(roleName)
                         select u.UserName);
            return roles.Count() > 0;
        }

        public void RemoveUsersFromRoles(string[] usernames, string[] roleNames)
        {
            UserData ud = FileManager.Load();
            var roles = (from u in ud.Users
                         where usernames.Contains(u.UserName) && roleNames.Intersect(u.Roles).Count() > 0
                         select u.UserName);
            FileManager.Save(ud);
        }

        public bool RoleExists(string roleName)
        {
            UserData ud = FileManager.Load();
            var roles = (from r in ud.Roles
                         where r.Equals(roleName)
                         select r);
            return roles.Count() > 0;
        }
    }
}
