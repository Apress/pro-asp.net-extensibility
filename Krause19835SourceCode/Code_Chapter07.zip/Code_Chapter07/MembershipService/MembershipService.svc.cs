﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Web.Caching;
using System.Xml.Linq;
using System.IO;
using System.Xml.Serialization;
using System.Web.Security;
using System.Security.Permissions;
using System.Reflection;
using System.Security.Cryptography;

namespace Apress.Extensibility.Membership
{

    [FileIOPermission(SecurityAction.LinkDemand)]
    public class MembershipService : IMembershipService
    {

        public MembershipService()
        {
        }

        #region IMembershipService Members

        public bool ChangePassword(string username, string oldPassword, string newPassword)
        {
            throw new NotImplementedException();
        }

        public bool ChangePasswordQuestionAndAnswer(string username, string password, string newPasswordQuestion, string newPasswordAnswer)
        {
            throw new NotImplementedException();
        }

        public User CreateUser(string username, string password, string email, string passwordQuestion, string passwordAnswer, bool isApproved, object providerUserKey, out System.Web.Security.MembershipCreateStatus status)
        {
            User user = null;
            UserData ud = FileManager.Load();
            // check users, consider adding more data here
            var hasUser = from u in ud.Users where u.UserName.Equals(username) select u;
            if (hasUser.Count() > 0)
            {
                status = MembershipCreateStatus.DuplicateUserName;
                return null;
            }
            var hasEmail = from u in ud.Users where u.Email.Equals(email) select u;
            if (hasEmail.Count() > 0)
            {
                status = MembershipCreateStatus.DuplicateEmail;
                return null;
            }
            try
            {
                user = new User(
                    username,
                    email,
                    passwordQuestion,
                    "",
                    isApproved,
                    false,
                    DateTime.Now,
                    DateTime.MinValue,
                    DateTime.MinValue,
                    DateTime.Now,
                    DateTime.MinValue);
                // Store Hash Only
                //System.Web.Security.FormsAuthentication.
                user.Password = FileManager.CalculateSHA1(password);
                ud.Users.Add(user);
                FileManager.Save(ud);
                status = MembershipCreateStatus.Success;
            }
            catch
            {
                status = MembershipCreateStatus.ProviderError;
            }
            return user;
        }

        public bool DeleteUser(string username, bool deleteAllRelatedData)
        {
            UserData ud = FileManager.Load();
            var user = (from u in ud.Users 
                        where u.UserName.Equals(username) 
                        select u).FirstOrDefault<User>();
            if (user != null)
            {
                ud.Users.Remove(user);
                FileManager.Save(ud);
                return true;
            }
            return false;
        }

        public List<User> FindUsersByEmail(string emailToMatch, int pageIndex, int pageSize, out int totalRecords)
        {
            UserData ud = FileManager.Load();
            var users = (from u in ud.Users 
                         where u.Email.Equals(emailToMatch) 
                         select u).ToList<User>();
            totalRecords = users.Count();
            return GetPaged(users, pageIndex, pageSize);
        }

        public List<User> FindUsersByName(string usernameToMatch, int pageIndex, int pageSize, out int totalRecords)
        {
            UserData ud = FileManager.Load();
            var users = (from u in ud.Users
                         where u.UserName.Equals(usernameToMatch) 
                         select u).ToList<User>();
            totalRecords = users.Count();
            return GetPaged(users, pageIndex, pageSize);
        }

        public List<User> GetAllUsers(int pageIndex, int pageSize, out int totalRecords)
        {
            UserData ud = FileManager.Load();
            totalRecords = ud.Users.Count;
            return GetPaged(ud.Users, pageIndex, pageSize);
        }

        private List<User> GetPaged(List<User> ud, int pageIndex, int pageSize)
        {
            pageSize = Math.Min(ud.Count, pageSize);
            return ud.GetRange(pageIndex * pageSize, pageSize); 
        }

        public int GetNumberOfUsersOnline()
        {
            // Just check logins of last 15 mins
            UserData ud = FileManager.Load();
            var users = (from u in ud.Users
                         where u.LastActivityDate.AddMinutes(15) > DateTime.Now 
                         select u);
            return users.Count();
        }

        public string GetPassword(string username, string answer)
        {
            UserData ud = FileManager.Load();
            var user = (from u in ud.Users
                        where u.UserName.Equals(username) && u.PasswordAnswer.Equals(answer) 
                        select u).First<User>();
            if (user != null)
            {
                return user.Password;
            }
            return null;
        }

        public User GetUser(string username, bool userIsOnline)
        {
            UserData ud = FileManager.Load();
            var user = (from u in ud.Users
                        where u.UserName.Equals(username) &&
                        (userIsOnline) ? 
                            u.LastActivityDate.AddMinutes(15) > DateTime.Now :
                            true // all users
                        select u).FirstOrDefault<User>();
            if (user != null)
            {
                return user;
            }
            return null;
        }

        public string GetUserNameByEmail(string email)
        {
            UserData ud = FileManager.Load();
            var user = (from u in ud.Users where u.Email.Equals(email) select u).FirstOrDefault<User>();
            if (user != null)
            {
                return user.UserName;
            }
            return null;
        }

        public string ResetPassword(string username, string answer)
        {
            UserData ud = FileManager.Load();
            var user = (from u in ud.Users where u.UserName.Equals(username) && u.PasswordAnswer.Equals(answer) select u).FirstOrDefault<User>();
            if (user != null)
            {
                return user.Password;
            }
            return null;
        }

        public bool UnlockUser(string userName)
        {
            throw new NotImplementedException();
        }

        public void UpdateUser(User user)
        {
            UserData ud = FileManager.Load();
            var userToUpdate = (from u in ud.Users where u.UserName.Equals(user.UserName) select u).FirstOrDefault<User>();
            foreach (PropertyInfo pi in user.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                PropertyInfo piTarget = typeof(User).GetProperty(pi.Name);
                if (piTarget != null)
                {
                    piTarget.SetValue(userToUpdate, pi.GetValue(user, null), null);
                }
            }
            FileManager.Save(ud);
        }

        public bool ValidateUser(string username, string password)
        {
            UserData ud = FileManager.Load();
            string hash = FileManager.CalculateSHA1(password);
            var user = (from u in ud.Users where u.UserName.Equals(username) && u.Password.Equals(hash) select u).FirstOrDefault<User>();
            user.LastActivityDate = DateTime.Now;
            FileManager.Save(ud);
            return (user != null);
        }

        #endregion

    }
}
