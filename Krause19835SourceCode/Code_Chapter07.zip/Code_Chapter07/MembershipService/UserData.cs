﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;
using System.Web.Security;
using System.IO;
using System.Security.Permissions;
using System.Runtime.Serialization;
using System.Xml.Schema;

namespace Apress.Extensibility.Membership
{

    public class UserData
    {

        public UserData()
        {
        }

        [XmlElement]
        public List<User> Users
        {
            get;
            set;
        }

        [XmlElement]
        public List<string> Roles
        {
            get;
            set;
        }

    }

    [Serializable]
    [DataContract]
    public class User
    {
        public User()
        {
        }

        public User(string name, string email, string passwordQuestion, string comment, bool isApproved, bool isLockedOut, DateTime creationDate, DateTime lastLoginDate, DateTime lastActivityDate, DateTime lastPasswordChangedDate, DateTime lastLockoutDate)
        {
            this.UserName = name;
            this.Email = email;
            this.Comment = comment;
            this.IsApproved = isApproved;
            this.IsLockedOut = isLockedOut;
            this.CreationDate = creationDate;
            this.LastLoginDate = lastLoginDate;
            this.PasswordQuestion = passwordQuestion;
            this.LastActivityDate = lastActivityDate;
            this.LastPasswordChangedDate = lastPasswordChangedDate;
            this.LastLockoutDate = lastLockoutDate;
        }

        [DataMember]
        [XmlElement]
        public string Comment { get; set; }
        [DataMember]
        [XmlElement]
        public DateTime CreationDate { get; set; }
        [DataMember]
        [XmlElement]
        public string Email { get; set; }
        [DataMember]
        [XmlAttribute]
        public bool IsApproved { get; set; }
        [DataMember]
        [XmlAttribute]
        public bool IsLockedOut { get; set; }
        [DataMember]
        [XmlElement]
        public DateTime LastActivityDate { get; set; }
        [DataMember]
        [XmlElement]
        public DateTime LastLockoutDate { get; set; }
        [DataMember]
        [XmlElement]
        public DateTime LastLoginDate { get; set; }
        [DataMember]
        [XmlElement]
        public DateTime LastPasswordChangedDate { get; set; }
        [DataMember]
        [XmlElement]
        public string PasswordQuestion { get; set; }
        [DataMember]
        [XmlElement]
        public string PasswordAnswer { get; set; }
        [DataMember]
        [XmlElement]
        public string UserName { get; set; }
        [DataMember]
        [XmlElement]
        public string Password { get; set; }

        [DataMember]
        [XmlArray(ElementName="Roles"), XmlArrayItem(ElementName="Role")]
        public List<string> Roles
        {
            get;
            set;
        }

        public bool ChangePassword(string oldPassword, string newPassword)
        {
            if (Password.Equals(oldPassword))
            {
                Password = newPassword;
                return true;
            }
            return false;
        }
        public bool ChangePasswordQuestionAndAnswer(string password, string newPasswordQuestion, string newPasswordAnswer)
        {
            if (Password.Equals(password))
            {
                PasswordQuestion = newPasswordQuestion;
                PasswordAnswer = newPasswordAnswer;
                return true;
            }
            return false;
        }
        public string GetPassword(string passwordAnswer)
        {
            return Password;
        }
        public string ResetPassword()
        {
            return Password;
        }
        public string ResetPassword(string passwordAnswer)
        {
            return Password;
        }
        public bool UnlockUser()
        {
            return IsLockedOut = false;
        }
    }


}
