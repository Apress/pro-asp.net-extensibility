﻿using System;
using System.Web.Security;
using Apress.Extensibility.Membership.RoleService;

namespace Apress.Extensibility.Membership
{
    public class WSRoleProvider : RoleProvider
    {

        private RoleServiceClient client;

        public override void Initialize(string name, System.Collections.Specialized.NameValueCollection config)
        {
            if (config == null)
                throw new ArgumentNullException("config");
            if (String.IsNullOrEmpty(name))
            {
                name = this.GetType().Name;
            }
            if (String.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "WS Based Membership Provider");
            }
            base.Initialize(name, config);
            client = new RoleServiceClient();
            // mandatory parameters
            ApplicationName = config["ApplicationName"];
        }

        public override void AddUsersToRoles(string[] usernames, string[] roleNames)
        {
            client.AddUsersToRoles(usernames, roleNames);
        }

        public override string ApplicationName
        {
            get;
            set;
        }

        public override void CreateRole(string roleName)
        {
            client.CreateRole(roleName);
        }

        public override bool DeleteRole(string roleName, bool throwOnPopulatedRole)
        {
            return client.DeleteRole(roleName, throwOnPopulatedRole);
        }

        public override string[] FindUsersInRole(string roleName, string usernameToMatch)
        {
            return client.FindUsersInRole(roleName, usernameToMatch);
        }

        public override string[] GetAllRoles()
        {
            return client.GetAllRoles();
        }

        public override string[] GetRolesForUser(string username)
        {
            return client.GetRolesForUser(username);
        }

        public override string[] GetUsersInRole(string roleName)
        {
            return client.GetUsersInRole(roleName);
        }

        public override bool IsUserInRole(string username, string roleName)
        {
            return client.IsUserInRole(username, roleName);
        }

        public override void RemoveUsersFromRoles(string[] usernames, string[] roleNames)
        {
            client.RemoveUsersFromRoles(usernames, roleNames);
        }

        public override bool RoleExists(string roleName)
        {
            return client.RoleExists(roleName);
        }
    }
}
