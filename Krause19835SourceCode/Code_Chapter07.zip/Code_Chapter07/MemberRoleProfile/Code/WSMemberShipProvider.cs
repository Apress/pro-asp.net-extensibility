﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using Apress.Extensibility.Membership;
using Apress.Extensibility.Membership.MembershipService;
using System.Reflection;

namespace Apress.Extensibility.Membership
{
    public class WSMemberShipProvider : MembershipProvider
    {

        private MembershipServiceClient client;
        private bool _enablePasswordReset;

        public override void Initialize(string name, System.Collections.Specialized.NameValueCollection config)
        {
            if (config == null)
                throw new ArgumentNullException("config");
            if (String.IsNullOrEmpty(name))
            {
                name = this.GetType().Name;
            }
            if (String.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "WS Based Membership Provider");
            }
            base.Initialize(name, config);
            client = new MembershipServiceClient();
            // volontary parameters
            if (!String.IsNullOrEmpty(config["EnablePasswordReset"]))
            {
                _enablePasswordReset = Boolean.Parse(config["EnablePasswordReset"]);
                config.Remove("EnablePasswordReset");
            }

            // mandatory parameters
            ApplicationName = config["ApplicationName"];

        }

        public override string ApplicationName
        {
            get;
            set;
        }

        public override bool ChangePassword(string username, string oldPassword, string newPassword)
        {
            return client.ChangePassword(username, oldPassword, newPassword);
        }

        public override bool ChangePasswordQuestionAndAnswer(string username, string password, string newPasswordQuestion, string newPasswordAnswer)
        {
            return client.ChangePasswordQuestionAndAnswer(username, password, newPasswordQuestion, newPasswordAnswer);
        }

        public override MembershipUser CreateUser(string username, string password, string email, string passwordQuestion, string passwordAnswer, bool isApproved, object providerUserKey, out MembershipCreateStatus status)
        {
            User user = client.CreateUser(out status, username, password, email, passwordQuestion, passwordAnswer, isApproved, providerUserKey);
            if (user == null) return null;
            MembershipUser mu = new MembershipUser(this.GetType().Name, 
                user.UserName,
                providerUserKey,
                user.Email,
                user.PasswordQuestion,
                "",
                user.IsApproved,
                user.IsLockedOut,
                user.CreationDate,
                user.LastLoginDate,
                user.LastActivityDate,
                user.LastPasswordChangedDate,
                user.LastLockoutDate
                );
            return mu;
        }

        public override bool DeleteUser(string username, bool deleteAllRelatedData)
        {
            return client.DeleteUser(username, deleteAllRelatedData);
        }

        public override bool EnablePasswordReset
        {
            get { return _enablePasswordReset; }
        }

        public override bool EnablePasswordRetrieval
        {
            get { throw new NotImplementedException(); }
        }

        public override MembershipUserCollection FindUsersByEmail(string emailToMatch, int pageIndex, int pageSize, out int totalRecords)
        {
            return CopyToMembershipCollection(client.FindUsersByEmail(out totalRecords, emailToMatch, pageIndex, pageSize));
        }

        public override MembershipUserCollection FindUsersByName(string usernameToMatch, int pageIndex, int pageSize, out int totalRecords)
        {
            return CopyToMembershipCollection(client.FindUsersByName(out totalRecords, usernameToMatch, pageIndex, pageSize));
        }

        public override MembershipUserCollection GetAllUsers(int pageIndex, int pageSize, out int totalRecords)
        {
            return CopyToMembershipCollection(client.GetAllUsers(out totalRecords, pageIndex, pageSize));
        }

        private MembershipUserCollection CopyToMembershipCollection(User[] users)
        {
            MembershipUserCollection muc = new MembershipUserCollection();
            foreach (User user in users)
            {
                muc.Add(CopyToMembershipUser(user));
            }
            return muc;
        }

        private MembershipUser CopyToMembershipUser(User user)
        {
            MembershipUser mu = new MembershipUser(this.GetType().Name,
                    user.UserName,
                    "",
                    user.Email,
                    user.PasswordQuestion,
                    user.Comment,
                    user.IsApproved,
                    user.IsLockedOut,
                    user.CreationDate,
                    user.LastLoginDate,
                    user.LastActivityDate,
                    user.LastPasswordChangedDate,
                    user.LastLockoutDate);
            return mu;
        }

        public override int GetNumberOfUsersOnline()
        {
            return client.GetNumberOfUsersOnline();
        }

        public override string GetPassword(string username, string answer)
        {
            return client.GetPassword(username, answer);
        }

        public override MembershipUser GetUser(string username, bool userIsOnline)
        {
            return CopyToMembershipUser(client.GetUserbyName(username, userIsOnline));
        }

        public override MembershipUser GetUser(object providerUserKey, bool userIsOnline)
        {
            throw new NotImplementedException();
        }

        public override string GetUserNameByEmail(string email)
        {
            return client.GetUserNameByEmail(email);
        }

        public override int MaxInvalidPasswordAttempts
        {
            get { return 5; }
        }

        public override int MinRequiredNonAlphanumericCharacters
        {
            get { return 1; }
        }

        public override int MinRequiredPasswordLength
        {
            get { return 6; }
        }

        public override int PasswordAttemptWindow
        {
            get { return 10; }
        }

        public override MembershipPasswordFormat PasswordFormat
        {
            get { return MembershipPasswordFormat.Clear; }
        }

        public override string PasswordStrengthRegularExpression
        {
            get { return ""; }
        }

        public override bool RequiresQuestionAndAnswer
        {
            get { return false; }
        }

        public override bool RequiresUniqueEmail
        {
            get { return false; }
        }

        public override string ResetPassword(string username, string answer)
        {
            return client.ResetPassword(username, answer);
        }

        public override bool UnlockUser(string userName)
        {
            throw new NotImplementedException();
        }

        public override void UpdateUser(MembershipUser user)
        {
            User u = new User();
            foreach (PropertyInfo pi in u.GetType().GetProperties())
            {
                PropertyInfo piTarget = user.GetType().GetProperty(pi.Name);
                if (piTarget != null)
                {
                    pi.SetValue(u, piTarget.GetValue(user, null), null);
                }
            }
            client.UpdateUser(u);
        }

        public override bool ValidateUser(string username, string password)
        {
            return client.ValidateUser(username, password);
        }
    }
}
