﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SetProfileData();
        }
    }

    protected void btnSend_Click(object sender, EventArgs e)
    {
        Profile.ForeColor = Color.FromName(drpForeColor.SelectedValue);
        Profile.BackColor = Color.FromName(drpBackColor.SelectedValue);
        Profile.User.Email = txtEmail.Text;
        SetProfileData();
    }

    private void SetProfileData()
    {
        PanelSettings.BackColor = Profile.BackColor;
        PanelSettings.ForeColor = Profile.ForeColor;
        Label l = new Label();
        l.Text = Profile.User.Email;
        PanelSettings.Controls.Add(l);
    }

}
