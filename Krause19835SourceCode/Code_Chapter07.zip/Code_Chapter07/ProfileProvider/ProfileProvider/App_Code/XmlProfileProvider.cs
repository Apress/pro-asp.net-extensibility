﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Configuration.Provider;
using System.IO;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Web;
using System.Web.Profile;
using System.Xml.Linq;

namespace Apress.Extensibility.ProfileProvider
{
    [SecurityPermission(SecurityAction.Assert,
    Flags = SecurityPermissionFlag.SerializationFormatter)]
    public class XmlProfileProvider : System.Web.Profile.ProfileProvider
    {

        private const string DATAPATH = "~/App_Data/Profile_Data";

        public override string ApplicationName
        {
            get { throw new NotSupportedException(); }
            set { throw new NotSupportedException(); }
        }

        public override void Initialize(string name, System.Collections.Specialized.NameValueCollection config)
        {
            base.Initialize(name, config);

            if (config.Count > 0)
                throw new ProviderException("Unrecognized attribute: " + config.GetKey(0));
        }

        public override System.Configuration.SettingsPropertyValueCollection GetPropertyValues(System.Configuration.SettingsContext context, System.Configuration.SettingsPropertyCollection collection)
        {
            SettingsPropertyValueCollection settings = new SettingsPropertyValueCollection();

            // Make sure we have an entry for this username in the XML data
            string username = context["UserName"] as string;
            if (!string.IsNullOrEmpty(username))
            {
                // Get the profile values for the user
                Dictionary<string, object> usersProperties = GetUserProfile(username);
                foreach (SettingsProperty property in collection)
                {
                    // Indicate that provider-specific serialized properties should be
                    // serialized as strings for primitive types and as XML for non-primitive types
                    if (property.PropertyType.IsPrimitive || property.PropertyType == typeof(String))
                        property.SerializeAs = SettingsSerializeAs.String;
                    else
                        property.SerializeAs = SettingsSerializeAs.ProviderSpecific;

                    // Create a new SettingsPropertyValue based on the current SettingsProperty object
                    SettingsPropertyValue setting = new SettingsPropertyValue(property);

                    if (usersProperties != null)
                    {
                        setting.IsDirty = false;

                        if (usersProperties.ContainsKey(property.Name))
                        {
                            setting.SerializedValue = usersProperties[property.Name];
                            setting.Deserialized = false;
                        }
                    }

                    settings.Add(setting);      // Add the settings value to the collection
                }

            }

            return settings;    // Return the settings collection
        }

        /// <summary>
        /// Searches the <see cref="ProfileFile"/> file for a &lt;user&gt; section with a matching username
        /// and returns this content as a string dictionary.
        /// </summary>
        /// <param name="username">The username to search for.</param>
        /// <returns>A string dictionary object representing the user's settings. If the supplied username is not found,
        /// <b>null</b> is returned.</returns>
        protected virtual Dictionary<string, object> GetUserProfile(string username)
        {
            Dictionary<string, object> propertyValues = new Dictionary<string, object>();

            XDocument xProfiles = XDocument.Load(ProfileFilePath);
            var xProf = (from p in xProfiles.Root.Elements() where p.Attribute("UserName").Value.Equals(username) select p);

            foreach (XElement xmlProperty in xProf.Elements())
            {
                SettingsSerializeAs ss = (SettingsSerializeAs)Enum.Parse(typeof(SettingsSerializeAs), xmlProperty.Attribute("serializedAs").Value);
                switch (ss)
                {
                    case SettingsSerializeAs.Binary:
                        propertyValues.Add(
                            xmlProperty.Name.LocalName,
                            Encoding.ASCII.GetString(Convert.FromBase64String((((XCData)xmlProperty.FirstNode).Value))));
                        break;
                    case SettingsSerializeAs.String:
                        propertyValues.Add(
                            xmlProperty.Name.LocalName,
                            xmlProperty.Value);
                        break;
                    case SettingsSerializeAs.ProviderSpecific:
                        if (xmlProperty.Attribute("typeConverter") != null)
                        {
                            TypeConverter converter = (TypeConverter)Activator.CreateInstance(Type.GetType(xmlProperty.Attribute("typeConverter").Value));
                            propertyValues.Add(
                                xmlProperty.Name.LocalName,
                                converter.ConvertFromString(xmlProperty.Value));
                        }
                        break;
                    case SettingsSerializeAs.Xml:
                        throw new NotSupportedException();
                }
            }

            return propertyValues;
        }


        public override void SetPropertyValues(System.Configuration.SettingsContext context, System.Configuration.SettingsPropertyValueCollection collection)
        {
            string username = context["UserName"] as string;
            bool userIsAuthenticated = (bool)context["IsAuthenticated"];
            // If no username is specified, or if no properties are to be saved, exit
            if (string.IsNullOrEmpty(username) || collection.Count == 0)
                return;

            if (!ExistsDirtyProperty(collection))
                return;

            XDocument xProfiles = XDocument.Load(ProfileFilePath);
            // check elements
            var xProf = (from p in xProfiles.Root.Elements() where p.Attribute("UserName").Value.Equals(username) select p).FirstOrDefault();
            if (xProf == null)
            {
                // Add a default empty profile
                xProf = new XElement("Profile", new XAttribute("UserName", username));
                xProfiles.Root.Add(xProf);
                xProfiles.Save(ProfileFilePath);
            }
            // assure empty element as write everything back
            xProf.RemoveNodes();
            foreach (SettingsPropertyValue setting in collection)
            {
                // If the user is not authenticated and the property does not allow anonymous access, skip serializing it
                if (!userIsAuthenticated && !(bool)setting.Property.Attributes["AllowAnonymous"])
                    continue;

                // Skip the current property if it's not dirty and is currently assigned its default value
                if (!setting.IsDirty && setting.UsingDefaultValue)
                    continue;

                // Serialize data based on property's SerializeAs type
                switch (setting.Property.SerializeAs)
                {
                    case SettingsSerializeAs.String:
                        xProf.Add(new XElement(
                            setting.Name,
                            Convert.ToString(setting.SerializedValue),
                            new XAttribute("serializedAs", setting.Property.SerializeAs)));
                        break;
                    case SettingsSerializeAs.ProviderSpecific:
                        // instead of XML we ask the default converter
                        TypeConverter converter = TypeDescriptor.GetConverter(setting.Property.PropertyType);
                        string data = converter.ConvertToString(setting.PropertyValue);
                        xProf.Add(new XElement(
                            setting.Name,
                            data,
                            new XAttribute("serializedAs", setting.Property.SerializeAs),
                            new XAttribute("typeConverter", converter.GetType().AssemblyQualifiedName)));
                        break;
                    case SettingsSerializeAs.Binary:
                        // encode the binary data using base64 encoding
                        string encodedBinaryData = Convert.ToBase64String(setting.SerializedValue as byte[]);
                        xProf.Add(new XElement(
                            setting.Name,
                            new XCData(encodedBinaryData),
                            new XAttribute("serializedAs", setting.Property.SerializeAs)));
                        break;
                    default:
                        // unknown serialize type!
                        throw new ProviderException(string.Format("Invalid value for SerializeAs; expected String, Xml, or Binary, received {0}", System.Enum.GetName(setting.Property.SerializeAs.GetType(), setting.Property.SerializeAs)));
                }
            }
            xProfiles.Save(ProfileFilePath);
        }

        protected virtual string ProfileFilePath
        {
            get
            {
                return Path.Combine(HttpContext.Current.Server.MapPath(DATAPATH), "Profiles.xml");
            }
        }

        protected virtual bool ExistsDirtyProperty(System.Configuration.SettingsPropertyValueCollection collection)
        {
            foreach (SettingsPropertyValue setting in collection)
                if (setting.IsDirty)
                    return true;

            // If we reach here, none are dirty
            return false;
        }

        public override int DeleteInactiveProfiles(ProfileAuthenticationOption authenticationOption, DateTime userInactiveSinceDate)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override int DeleteProfiles(string[] usernames)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override int DeleteProfiles(ProfileInfoCollection profiles)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override ProfileInfoCollection FindInactiveProfilesByUserName(ProfileAuthenticationOption authenticationOption, string usernameToMatch, DateTime userInactiveSinceDate, int pageIndex, int pageSize, out int totalRecords)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override ProfileInfoCollection FindProfilesByUserName(ProfileAuthenticationOption authenticationOption, string usernameToMatch, int pageIndex, int pageSize, out int totalRecords)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override ProfileInfoCollection GetAllInactiveProfiles(ProfileAuthenticationOption authenticationOption, DateTime userInactiveSinceDate, int pageIndex, int pageSize, out int totalRecords)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override ProfileInfoCollection GetAllProfiles(ProfileAuthenticationOption authenticationOption, int pageIndex, int pageSize, out int totalRecords)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override int GetNumberOfInactiveProfiles(ProfileAuthenticationOption authenticationOption, DateTime userInactiveSinceDate)
        {
            throw new Exception("The method or operation is not implemented.");
        }

    }
}