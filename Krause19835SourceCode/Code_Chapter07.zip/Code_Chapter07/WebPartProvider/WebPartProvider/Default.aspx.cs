﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace WebPartProvider
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Create a menu of web part modes
                MenuItem rootItem = new MenuItem("Select Web Part Mode");
                foreach (WebPartDisplayMode mode in WebPartManager1.DisplayModes)
                {
                    rootItem.ChildItems.Add(new MenuItem(mode.Name));
                }
                Menu1.Items.Add(rootItem);
            }
        }

        protected void Menu1_MenuItemClick(object sender, MenuEventArgs e)
        {
            WebPartManager1.DisplayMode = WebPartManager1.DisplayModes[e.Item.Text];
        }
    }
}
