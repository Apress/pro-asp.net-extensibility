﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls.WebParts;
using System.IO;
using System.Web.Hosting;
using System.Data;
using System.Xml.Linq;
using System.Xml.XPath;

namespace Apress.Extensibility.WebPartProvider
{
    public class XmlPersonalizationProvider : PersonalizationProvider
    {
        private const string SETTINGSNAME = "WPSettings.xml";
        private const string SETTINGSTAG = "WPSettings";
        private string configFile;

        public override void Initialize(string name, System.Collections.Specialized.NameValueCollection config)
        {
            base.Initialize(name, config);
            configFile = HttpContext.Current.Request.MapPath(Path.Combine("~/App_Data/", SETTINGSNAME));
            // XML
            if (!File.Exists(configFile))
            {
                XDocument cfgDoc = new XDocument(
                    new XElement("WebPartData", new XAttribute("Created", DateTime.Now.ToShortDateString()),
                        new XElement("UserScope"),
                        new XElement("SharedScope")));
                cfgDoc.Declaration = new XDeclaration("1.0", "utf-8", "true");
                cfgDoc.Save(configFile);
            }
        }

        // NOTE: only Shared-scope personalization is loaded
        protected override void LoadPersonalizationBlobs(
          WebPartManager webPartManager,
          string path,
          string userName,
          ref byte[] sharedDataBlob,
          ref byte[] userDataBlob)
        {
            string fullPath = HttpContext.Current.Request.MapPath(path);
            XDocument cfgDoc = XDocument.Load(configFile);
            var root = cfgDoc.Element("WebPartData");
            if (userName == null)
            {
                object cachedPageSettings = HttpContext.Current.Cache[SETTINGSTAG + ":" + path];
                if (cachedPageSettings != null)
                {
                    sharedDataBlob = (byte[])cachedPageSettings;
                }
                else
                {
                    var shared = root.Element("SharedScope")
                                 .Elements("Page")
                                 .Single(n => n.Attribute("name").Value.Equals(userName));
                    if (shared == null)
                    {
                        sharedDataBlob = null;
                    }
                    else
                    {
                        sharedDataBlob = Convert.FromBase64String(shared.Value);
                        // cache shared settings
                        webPartManager.Page.Cache.Insert(SETTINGSTAG + ":" + path, sharedDataBlob, new System.Web.Caching.CacheDependency(configFile));
                    }
                }
            }
            else
            {
                var pageElement = root.XPathSelectElement(
                    String.Format("//UserScope/User[@name='{0}']/Page[@name='{1}']", 
                    userName, 
                    path));                    
                if (pageElement != null)
                {
                    userDataBlob = Convert.FromBase64String(pageElement.Value);
                }
            }
        }

        protected override void ResetPersonalizationBlob(
          WebPartManager webPartManager,
          string path,
          string userName)
        {
        }

        // NOTE: only Shared-scope personalization is saved
        protected override void SavePersonalizationBlob(
          WebPartManager webPartManager,
          string path,
          string userName,
          byte[] dataBlob)
        {
            string fullPath = HttpContext.Current.Request.MapPath(path);
            string sBlob = Convert.ToBase64String(dataBlob); 
            lock (this)
            {
                XDocument cfgDoc = XDocument.Load(configFile);
                var root = cfgDoc.Element("WebPartData");
                if (!String.IsNullOrEmpty(userName))
                {
                    // Scope: user
                    var userElement = root.XPathSelectElement(
                            String.Format("//UserScope/User[@name='{0}']",
                            userName));
                    if (userElement == null)
                    {
                        userElement = root.Element("UserScope");
                        // no user, add complete tree
                        userElement.Add(
                            new XElement("User", new XAttribute("name", userName),
                                new XElement("Page", new XAttribute("name", path),
                                    sBlob)));
                    }
                    else
                    {
                        // with user, check page
                        var pageElement = userElement.Elements("Page")
                                          .Single(n => n.Attribute("name").Value.Equals(path));
                        if (pageElement == null)
                        {
                            // no page
                            userElement.Add(new XElement("Page", 
                                new XAttribute("name", path),
                                    sBlob));
                        }
                        else
                        {
                            // new data for page
                            pageElement.Value = sBlob;
                        }
                    }
                }
                else
                {
                    // Scope: Shared
                    var sharedElement = root.Elements("SharedScope")
                                        .Elements("Page")
                                        .Single(p => p.Attribute("Name").Value.Equals(path));
                    if (sharedElement == null)
                    {
                        sharedElement.Add(new XElement("Page",
                            new XAttribute("name", path),
                            sBlob));
                    }
                    else
                    {
                        sharedElement.Value = sBlob;
                    }
                }
                cfgDoc.Save(configFile);
            }
        }

        public override string ApplicationName
        {
            get;
            set;
        }

        public override int GetCountOfState(
          PersonalizationScope scope,
          PersonalizationStateQuery query)
        {
            return 0;
        }

        public override PersonalizationStateInfoCollection FindState(
          PersonalizationScope scope,
          PersonalizationStateQuery query,
          int pageIndex,
          int pageSize,
          out int totalRecords)
        {
            totalRecords = 0;
            return null;
        }

        public override int ResetState(
          PersonalizationScope scope,
          string[] paths,
          string[] usernames)
        {
            return 0;
        }

        public override int ResetUserState(
          string path,
          DateTime userInactiveSinceDate)
        {
            return 0;
        }
    }

}
