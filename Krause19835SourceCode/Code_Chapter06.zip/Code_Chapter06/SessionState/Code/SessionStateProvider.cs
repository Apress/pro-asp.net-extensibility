﻿using System;
using System.Collections.Specialized;
using System.IO;
using System.Web;
using System.Web.Configuration;
using System.Web.SessionState;

namespace Apress.Extensibility.SessionState
{
    public sealed class FileSessionStateStore : SessionStateStoreProviderBase
    {
        private SessionStateSection sessconfig = null;
        private string basePath;
        private string applicationName;

        public string ApplicationName
        {
            get
            {
                return applicationName;
            }
        }

        public override void Initialize(string name, NameValueCollection config)
        {
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }
            if (String.IsNullOrEmpty(name))
            {
                name = "FileSessionStateStore";
            }
            if (String.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "File Session State Store provider example");
            }
            base.Initialize(name, config);
            applicationName = System.Web.Hosting.HostingEnvironment.ApplicationVirtualPath;
            basePath = config["basePath"];
            System.Configuration.Configuration cfg = WebConfigurationManager.OpenWebConfiguration(ApplicationName);
            sessconfig = (SessionStateSection)cfg.GetSection("system.web/sessionState");
        }

        public override void Dispose()
        {
        }

        public override bool SetItemExpireCallback(SessionStateItemExpireCallback expireCallback)
        {
            return false;
        }

        public override void SetAndReleaseItemExclusive(HttpContext context, string id, SessionStateStoreData item, Object lockId, bool newItem)
        {
            // Serialize the SessionStateItemCollection as a string.
            string sessItems = Serialize((SessionStateItemCollection)item.Items);
            string path = Path.Combine(basePath, String.Format("{0}.ssd", id));
            FileStream fs = null;
            try
            {
                if (newItem)
                {
                    if (File.Exists(path))
                    {
                        File.Delete(path);
                    }
                    fs = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.Read);
                    // new
                }
                else
                {
                    // update
                    fs = new FileStream(path, FileMode.Open, FileAccess.Write, FileShare.Read);
                }
                StreamWriter sw = new StreamWriter(fs);
                sw.Write(sessItems);
                sw.Close();
            }
            catch (IOException exception)
            {
                // add error handling
            }
            finally
            {
                if (fs != null)
                {
                    fs.Close();
                    fs.Dispose();
                }
            }
        }

        public override SessionStateStoreData GetItem(HttpContext context, string id, out bool locked, out TimeSpan lockAge, out object lockId, out SessionStateActions actionFlags)
        {
            return GetSessionStoreItem(false, context, id, out locked, out lockAge, out lockId, out actionFlags);
        }

        public override SessionStateStoreData GetItemExclusive(HttpContext context, string id, out bool locked, out TimeSpan lockAge, out object lockId, out SessionStateActions actionFlags)
        {
            return GetSessionStoreItem(true, context, id, out locked, out lockAge, out lockId, out actionFlags);
        }

        private SessionStateStoreData GetSessionStoreItem(bool lockRecord, HttpContext context, string id, out bool locked, out TimeSpan lockAge, out object lockId, out SessionStateActions actionFlags)
        {
            // Initial values for Return value and out parameters.
            SessionStateStoreData item = null;
            lockAge = TimeSpan.Zero;
            lockId = null;
            locked = false;
            actionFlags = SessionStateActions.None;
            string serializedItems = String.Empty;
            string path = Path.Combine(basePath, String.Format("{0}.ssd", id));
            FileStream fs = null;
            try
            {
                fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
                StreamReader sr = new StreamReader(fs);
                serializedItems = sr.ReadToEnd();
                sr.Close();
            }
            catch (IOException)
            {
                // add error handling here
            }
            finally
            {
                if (fs != null)
                {
                    fs.Close();
                    fs.Dispose();
                }
            }
            item = Deserialize(context, serializedItems, 1024);
            return item;
        }

        private string Serialize(SessionStateItemCollection items)
        {
            MemoryStream ms = new MemoryStream();
            BinaryWriter writer = new BinaryWriter(ms);
            if (items != null)
            {
                items.Serialize(writer);
            }
            writer.Close();
            return Convert.ToBase64String(ms.ToArray());
        }

        private SessionStateStoreData Deserialize(HttpContext context, string serializedItems, int timeout)
        {
            MemoryStream ms = new MemoryStream(Convert.FromBase64String(serializedItems));
            SessionStateItemCollection sessionItems = new SessionStateItemCollection();
            if (ms.Length > 0)
            {
                BinaryReader reader = new BinaryReader(ms);
                sessionItems = SessionStateItemCollection.Deserialize(reader);
            }
            return new SessionStateStoreData(sessionItems, SessionStateUtility.GetSessionStaticObjects(context), timeout);
        }

        public override void ReleaseItemExclusive(HttpContext context, string id, object lockId)
        {
            // release lock
        }


        public override void RemoveItem(HttpContext context, string id, object lockId, SessionStateStoreData item)
        {
            string path = Path.Combine(basePath, String.Format("{0}.ssd", id));
            File.Delete(path);
        }

        public override void CreateUninitializedItem(HttpContext context, string id, int timeout)
        {
            string path = Path.Combine(basePath, String.Format("{0}.ssd", id));
            FileStream fs = File.Create(path);
            fs.Close();
        }

        public override SessionStateStoreData CreateNewStoreData(HttpContext context, int timeout)
        {

            return new SessionStateStoreData(new SessionStateItemCollection(), SessionStateUtility.GetSessionStaticObjects(context), timeout);
        }

        public override void ResetItemTimeout(HttpContext context, string id)
        {
            // refresh item
        }

        public override void InitializeRequest(HttpContext context)
        {
        }

        public override void EndRequest(HttpContext context)
        {

        }

    }
}