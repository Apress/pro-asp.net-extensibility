﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;
using System.Web.Configuration;
using System.Configuration;

namespace Apress.Extensibility.SessionState
{
    public class SimpleSessionIDManager : SessionIDManager
    {

        public override string CreateSessionID(HttpContext context)
        {
            return Guid.NewGuid().ToString();
        }

        public override bool Validate(string id)
        {
            try
            {
                Guid testGuid = new Guid(id);
                if (id.Equals(testGuid.ToString()))
                {
                    return true;
                }
            }
            catch
            {                
            }
            return false;
        }

    }
}
