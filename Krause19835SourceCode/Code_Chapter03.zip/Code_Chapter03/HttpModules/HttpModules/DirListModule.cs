﻿using System;
using System.Web;

namespace Apress.AspNetExtensibility.HttpModules
{
    public class DirListModule : IHttpModule
    {

        #region IHttpModule Members

        public void Dispose()
        {
        }

        public void Init(HttpApplication context)
        {
        }

        #endregion

    }
}
